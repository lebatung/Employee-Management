/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main.model;

/**
 *
 * @author Ba Tung
 */
public class CaLam {
    private String maNV, hoTen, ngayLam, chucVu, buoi;
    private String maCa;

    public CaLam() {
    }

    public CaLam(String maCa,String maNV, String hoTen, String ngayLam, String chucVu, String buoi) {
        this.maCa = maCa;
        this.maNV = maNV;
        this.hoTen = hoTen;
        this.ngayLam = ngayLam;
        this.chucVu = chucVu;
        this.buoi = buoi;
    }
    public String getMaCa(){
        return maCa;
    }
    public String getMaNV() {
        return maNV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getNgayLam() {
        return ngayLam;
    }

    public String getChucVu() {
        return chucVu;
    }

    public String getBuoi() {
        return buoi;
    }
    public void setMaCa(String maCa){
        this.maCa = maCa;
    }
    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setNgayLam(String ngayLam) {
        this.ngayLam = ngayLam;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu;
    }

    public void setBuoi(String buoi) {
        this.buoi = buoi;
    }
    
}
