/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main.model;

/**
 *
 * @author BaTung
 */
public class Auth {
    String curUser, curPass;

    public Auth() {
    }

    public Auth(String curUser, String curPass) {
        this.curUser = curUser;
        this.curPass = curPass;
    }

    public String getCurUser() {
        return curUser;
    }

    public String getCurPass() {
        return curPass;
    }

    public void setCurUser(String curUser) {
        this.curUser = curUser;
    }

    public void setCurPass(String curPass) {
        this.curPass = curPass;
    }
    
}
