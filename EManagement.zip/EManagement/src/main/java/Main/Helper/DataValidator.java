/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main.Helper;

import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Ba Tung
 */
public class DataValidator {

    public static void ValidateEmpty(JTextField field, StringBuilder sb, String errorMessage) {
        if (field.getText().equals("")) {
            sb.append(errorMessage).append("\n");
            field.setBackground(Color.yellow);
            field.requestFocus();            
        } else {
            field.setBackground(Color.white);
        }
        
    }
    
    public static void ValidateEmpty(JPasswordField field, StringBuilder sb, String errorMessage) {
        String passWord = new String(field.getPassword());
        if (passWord.equals("")) {
            sb.append(errorMessage).append("\n");
            field.setBackground(Color.yellow);
            field.requestFocus();            
        } else {
            field.setBackground(Color.white);
        }
        
    }
}
