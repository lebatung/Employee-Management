/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main.Dao;

import Main.Helper.DatabaseHelper;
import Main.model.NhanVien;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Ba Tung
 */
public class NhanVienDao {
    public boolean insert(NhanVien nv) throws Exception{
        String sql = "insert into ObjnhanVien(manv, hoten, gioitinh, ngaysinh, sodienthoai, diachi, chucvu) values(?,?,?,?,?,?,?)";
        try (
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            
            ){
            pstmt.setString(1, nv.getMaNV());
            pstmt.setString(2, nv.getHoTen());
            pstmt.setString(3, nv.getGioiTinh());
            pstmt.setString(4, nv.getNgaySinh());
            pstmt.setString(5, nv.getSdt());
            pstmt.setString(6, nv.getDiaChi());
            pstmt.setString(7, nv.getChucVu());
    
            return pstmt.executeUpdate() > 0;
        }
    }
    public boolean update(NhanVien nv) throws Exception{
        String sql = "update ObjnhanVien set hoten = ?, gioitinh = ?, ngaysinh = ?, sodienthoai = ?, diachi = ?, chucvu = ? " + " where MaNV = ? ";
        try (
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            
            ){
            pstmt.setString(7, nv.getMaNV());
            pstmt.setString(1, nv.getHoTen());
            pstmt.setString(2, nv.getGioiTinh());
            pstmt.setString(3, nv.getNgaySinh());
            pstmt.setString(4, nv.getSdt());
            pstmt.setString(5, nv.getDiaChi());
            pstmt.setString(6, nv.getChucVu());
    
            return pstmt.executeUpdate() > 0;
        }
    }
    public boolean delete(String maNV) throws Exception{
        String sql = "delete from ObjnhanVien " + " where manv = ? ";
        try (
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            
            ){
            pstmt.setString(1, maNV);
    
            return pstmt.executeUpdate() > 0;
        }
    }
}
