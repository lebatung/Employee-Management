/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main.Dao;

import Main.model.NguoiDung;
import Main.Helper.DatabaseHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Ba Tung
 */
public class NguoiDungDao {

    public NguoiDung checkLogin(String tenDangNhap, String matKhau) throws Exception {
        String sql = "select tenDangNhap, matKhau, vaiTro from objnguoidung " + "where tenDangNhap = ? and matKhau = ?";
        try (
                 Connection con = DatabaseHelper.openConnection();  PreparedStatement pstmt = con.prepareStatement(sql);) {
            pstmt.setString(1, tenDangNhap);
            pstmt.setString(2, matKhau);

            try ( ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    NguoiDung nd = new NguoiDung();
                    nd.setTenDangNhap(tenDangNhap);
                    nd.setMatKhau(matKhau);
                    nd.setVaiTro(rs.getString("vaitro"));
                    return nd;
                }
            }
        }
        return null;
    }

    public NguoiDung checkPass(String matKhau) throws Exception {
        String sql = "select matKhau from objnguoidung " + "where matKhau = ?";
        try (
                 Connection con = DatabaseHelper.openConnection();  PreparedStatement pstmt = con.prepareStatement(sql);) {
            pstmt.setString(1, matKhau);

            try ( ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    NguoiDung nd = new NguoiDung();
                    nd.setMatKhau(matKhau);
                    return nd;
                }
            }
        }
        return null;
    }

    public boolean update(NguoiDung nd) throws Exception {
        String sql = "update ObjnguoiDung set matKhau = ? " + " where tenDangNhap = ? ";
        try (
                 Connection con = DatabaseHelper.openConnection();  PreparedStatement pstmt = con.prepareStatement(sql);) {
            pstmt.setString(2, nd.getTenDangNhap());
            pstmt.setString(1, nd.getMatKhau());

            return pstmt.executeUpdate() > 0;
        }
    }
}
