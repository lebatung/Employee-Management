/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main.Dao;

import Main.Helper.DatabaseHelper;
import Main.model.CaLam;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Ba Tung
 */
public class caLamDao {
    public boolean insert(CaLam cl) throws Exception{
        String sql = "insert into ObjcaLam(maca, hoten, chucvu, ngaylam, buoi) values(?,?,?,?,?)";
        try (
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            
            ){
            pstmt.setString(1, cl.getMaCa());
            pstmt.setString(2, cl.getHoTen());
            pstmt.setString(4, cl.getNgayLam());
            pstmt.setString(3, cl.getChucVu());
            pstmt.setString(5, cl.getBuoi());
    
            return pstmt.executeUpdate() > 0;
        }
    }
    public boolean update(CaLam cl) throws Exception{
        String sql = "update ObjcaLam set hoten = ?, chucvu = ?, ngaylam = ?, buoi = ? " + " where maCa = ? ";
        try (
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            
            ){
            pstmt.setString(5, cl.getMaCa());
            pstmt.setString(1, cl.getHoTen());
            pstmt.setString(2, cl.getChucVu());
            pstmt.setString(3, cl.getNgayLam());
            pstmt.setString(4, cl.getBuoi());
    
            return pstmt.executeUpdate() > 0;
        }
    }
    public boolean delete(String maCa) throws Exception{
        String sql = "delete from ObjcaLam " + " where maCa = ?";
        try (
            Connection con = DatabaseHelper.openConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            
            ){
            pstmt.setString(1, maCa);
    
            return pstmt.executeUpdate() > 0;
        }
    }
    
}
