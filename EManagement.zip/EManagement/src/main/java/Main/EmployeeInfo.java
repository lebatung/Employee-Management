/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Main;

import Main.Dao.NhanVienDao;
import Main.Dao.caLamDao;
import Main.Helper.DatabaseHelper;
import Main.Windows.doiMatKhau;
import Main.model.CaLam;
import Main.model.NguoiDung;
import Main.model.NhanVien;
import java.awt.Color;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Ba Tung
 */
public class EmployeeInfo extends javax.swing.JFrame {

    DefaultTableModel tblModel;
    DefaultTableModel tblModeldanhSachNVcl;
    DefaultTableModel tblModelcaLam;
    DefaultTableModel tblModelLuong;
    /**
     * Creates new form EmployeeInfo
     */
    public EmployeeInfo() {
        initComponents();

        initTable();
        loadEmployee();

    }

    private void initTable() {
        //tbdanhSachNV
        tblModel = new DefaultTableModel();
        tblModel.setColumnIdentifiers(new String[]{"Mã nhân viên", "Họ tên", "Giới tính", "Ngày sinh", "Số điện thoại", "Địa chỉ", "Chức vụ"});
        tbdanhSachNV.setModel(tblModel);
        //tbdanhSachNVcl
        tblModeldanhSachNVcl = new DefaultTableModel();
        tblModeldanhSachNVcl.setColumnIdentifiers(new String[]{"Mã Nhân viên", "Họ tên", "Chức vụ"});
        tbdanhSachNVcl.setModel(tblModeldanhSachNVcl);
        tbdanhSachNVl.setModel(tblModeldanhSachNVcl);
        //tbcaLam
        tblModelcaLam = new DefaultTableModel();
        tblModelcaLam.setColumnIdentifiers(new String[]{"Mã ca làm", "Họ tên", "Chức vụ", "Ngày làm", "Buổi"});
        tbcaLam.setModel(tblModelcaLam);
        //tbluong
        tblModelLuong = new DefaultTableModel();
        tblModelLuong.setColumnIdentifiers(new String[]{"Mã nhân viên", "Họ tên", "Chức vụ", "Số ngày làm", "Đơn giá", "Tổng lương (Nghìn đồng)"});
        tbluong.setModel(tblModelLuong);
    }

    private void loadEmployee() {
        try {
            Connection con = DatabaseHelper.openConnection();
            String sql = "select * from ObjnhanVien";
            PreparedStatement pstmt = con.prepareStatement(sql);
            String sql2 = "select * from ObjcaLam";
            PreparedStatement pstmt2 = con.prepareStatement(sql2);
            String sql3 = "select * from luong";
            PreparedStatement pstmt3 = con.prepareStatement(sql3);
            //tbdanhSachNV
            ResultSet rs = pstmt.executeQuery();
            tblModel.setRowCount(0);
            while (rs.next()) {
                String[] row = new String[]{
                    rs.getString("maNV"),
                    rs.getString("hoTen"),
                    rs.getString("gioiTinh"),
                    rs.getString("ngaySinh"),
                    rs.getString("soDienThoai"),
                    rs.getString("diaChi"),
                    rs.getString("chucVu")
                };
                tblModel.addRow(row);
            }
            tblModel.fireTableDataChanged();
            rs.close();
            //

            //tbdanhSachNVcl tblModeldanhSachNVcl
            ResultSet rs1 = pstmt.executeQuery();
            tblModeldanhSachNVcl.setRowCount(0);
            while (rs1.next()) {
                String[] row1 = new String[]{
                    rs1.getString("maNV"),
                    rs1.getString("hoTen"),
                    rs1.getString("chucVu")
                };
                tblModeldanhSachNVcl.addRow(row1);
            }
            tblModeldanhSachNVcl.fireTableDataChanged();
            rs1.close();
            //
            //tbcaLam tblModelcaLam
            ResultSet rs2 = pstmt2.executeQuery();
            tblModelcaLam.setRowCount(0);
            while (rs2.next()) {
                String[] row2 = new String[]{
                    rs2.getString("maCa"),
                    rs2.getString("hoTen"),
                    rs2.getString("chucVu"),
                    rs2.getString("ngayLam"),
                    rs2.getString("buoi")
                };
                tblModelcaLam.addRow(row2);
            }
            tblModelcaLam.fireTableDataChanged();
            rs2.close();
            //
            
            //tbluong tblModelLuong
            ResultSet rs3 = pstmt3.executeQuery();
            tblModelLuong.setRowCount(0);
            while (rs3.next()){
                String[] row3 = new String[]{
                    rs3.getString("maNV"),
                    rs3.getString("hoTen"),
                    rs3.getString("chucVu"),
                    rs3.getString("soNgayLam"),
                    rs3.getString("donGiaLuong"),
                    rs3.getString("tongLuong"),
                };
                tblModelLuong.addRow(row3);
            }
            tblModelLuong.fireTableDataChanged();
            rs3.close();

            //
            pstmt.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel17 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbngay = new javax.swing.JComboBox<>();
        cbthang = new javax.swing.JComboBox<>();
        cbnam = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtadiaChi = new javax.swing.JTextArea();
        txthoTen = new javax.swing.JTextField();
        cbchucVu = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbdanhSachNV = new javax.swing.JTable();
        btnnhapMoi = new javax.swing.JButton();
        txtmaNhanVien = new javax.swing.JTextField();
        txtsoDienThoai = new javax.swing.JTextField();
        btnxoa = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        rdbnam = new javax.swing.JRadioButton();
        rdbnu = new javax.swing.JRadioButton();
        btnluu = new javax.swing.JButton();
        btncapNhat = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbcaLam = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        txtmaCacl = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txthoTencl = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtchucVucl = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        cbngaycl = new javax.swing.JComboBox<>();
        cbthangcl = new javax.swing.JComboBox<>();
        cbnamcl = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        cbbuoicl = new javax.swing.JComboBox<>();
        btnthemCaLam = new javax.swing.JButton();
        btnsuaCaLam = new javax.swing.JButton();
        btnxoaCaLam = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbdanhSachNVcl = new javax.swing.JTable();
        jLabel23 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        txtmaNhanVienl = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txthoTenl = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        txtchucVul = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbluong = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        tbdanhSachNVl = new javax.swing.JTable();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        cbngayltu = new javax.swing.JComboBox<>();
        jLabel31 = new javax.swing.JLabel();
        cbthangltu = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        cbnamltu = new javax.swing.JComboBox<>();
        cbnamlden = new javax.swing.JComboBox<>();
        cbthanglden = new javax.swing.JComboBox<>();
        cbngaylden = new javax.swing.JComboBox<>();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        tinhLuong = new javax.swing.JButton();
        btnlamMoi = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản lý nhân viên");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel11.setText("HỆ THỐNG QUẢN LÝ NHÂN VIÊN");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel12.setText("SINH VIÊN THỰC HIỆN:  LÊ BÁ TÙNG");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jLabel14.setText("MSSV:  B1906606");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/quan-ly-nhan-su-2-e1632800759551-removebg-preview.png"))); // NOI18N

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setText("Đăng xuất");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(0, 90, Short.MAX_VALUE)
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 680, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel14))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(189, 189, 189)
                        .addComponent(jLabel11)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, 394, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2)))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel14))
                .addContainerGap())
        );

        jTabbedPane2.addTab("Trang chủ", jPanel6);

        jLabel1.setText("Mã nhân viên: ");

        jLabel2.setText("Họ tên: ");

        jLabel3.setText("Ngày sinh: ");

        jLabel4.setText("Ngày: ");

        jLabel5.setText("Tháng: ");

        jLabel6.setText("Năm: ");

        cbngay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        cbthang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", " " }));

        cbnam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004" }));

        jLabel7.setText("Số điện thoại: ");

        jLabel8.setText("Chức vụ:");

        jLabel9.setText("Địa chỉ: ");

        txtadiaChi.setColumns(20);
        txtadiaChi.setRows(5);
        jScrollPane1.setViewportView(txtadiaChi);

        cbchucVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "Quan ly", "Le tan", "Phuc vu", "Bao ve", "Don dep", " " }));

        tbdanhSachNV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Họ tên", "Giới tính", "Ngày sinh", "Số điện thoại", "Chức vụ", "Địa chỉ"
            }
        ));
        tbdanhSachNV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbdanhSachNVMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbdanhSachNV);

        btnnhapMoi.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnnhapMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/new-icon-16.png"))); // NOI18N
        btnnhapMoi.setText("Nhập mới");
        btnnhapMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnhapMoiActionPerformed(evt);
            }
        });

        btnxoa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnxoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Actions-edit-delete-icon-16.png"))); // NOI18N
        btnxoa.setText("Xóa");
        btnxoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnxoaActionPerformed(evt);
            }
        });

        jLabel10.setText("Giới tính:");

        buttonGroup1.add(rdbnam);
        rdbnam.setText("Nam");

        buttonGroup1.add(rdbnu);
        rdbnu.setText("Nữ");

        btnluu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnluu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Save-icon.png"))); // NOI18N
        btnluu.setText("Lưu");
        btnluu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnluuActionPerformed(evt);
            }
        });

        btncapNhat.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btncapNhat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Actions-document-edit-icon-16.png"))); // NOI18N
        btncapNhat.setText("Cập nhật");
        btncapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncapNhatActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/logout-icon-16.png"))); // NOI18N
        jButton1.setText("Thoát");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(btnluu)
                        .addGap(18, 18, 18)
                        .addComponent(btncapNhat)
                        .addGap(18, 18, 18)
                        .addComponent(btnnhapMoi)
                        .addGap(18, 18, 18)
                        .addComponent(btnxoa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addComponent(rdbnam)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(rdbnu))
                                    .addComponent(txtmaNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtsoDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbchucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addGap(23, 23, 23))
                                        .addGroup(jPanel7Layout.createSequentialGroup()
                                            .addComponent(jLabel9)
                                            .addGap(24, 24, 24)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 500, Short.MAX_VALUE)))
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txthoTen, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbngay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbthang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbnam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(56, Short.MAX_VALUE))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtmaNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(3, 3, 3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txthoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(28, 28, 28)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(rdbnam)
                    .addComponent(rdbnu)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(cbngay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(cbthang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cbnam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtsoDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cbchucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnluu)
                            .addComponent(btncapNhat)
                            .addComponent(btnnhapMoi)
                            .addComponent(btnxoa)
                            .addComponent(jButton1))
                        .addGap(37, 37, 37)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane2.addTab("Thông tin nhân viên", jPanel7);

        tbcaLam.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã ca làm", "Họ tên", "Chức vụ", "Ngày làm", "Buổi"
            }
        ));
        tbcaLam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbcaLamMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbcaLam);

        jLabel15.setText("Mã ca làm:");

        jLabel16.setText("Họ tên:");

        jLabel17.setText("Chức vụ:");

        jLabel18.setText("Ngày làm:");

        jLabel19.setText("Ngày:");

        jLabel20.setText("Tháng:");

        jLabel21.setText("Năm:");

        cbngaycl.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        cbthangcl.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));

        cbnamcl.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "2022" }));

        jLabel22.setText("Buổi:");

        cbbuoicl.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "Sang", "Chieu" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addComponent(jLabel17)
                    .addComponent(jLabel16)
                    .addComponent(jLabel22)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txthoTencl, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                    .addComponent(txtchucVucl)
                    .addComponent(txtmaCacl, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(55, 55, 55))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(cbngaycl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(cbthangcl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(cbnamcl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(cbbuoicl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtmaCacl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txthoTencl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtchucVucl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbngaycl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbthangcl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbnamcl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(cbbuoicl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnthemCaLam.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnthemCaLam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Save-icon.png"))); // NOI18N
        btnthemCaLam.setText("Thêm ca làm");
        btnthemCaLam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnthemCaLamActionPerformed(evt);
            }
        });

        btnsuaCaLam.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnsuaCaLam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Actions-document-edit-icon-16.png"))); // NOI18N
        btnsuaCaLam.setText("Sửa ca làm");
        btnsuaCaLam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsuaCaLamActionPerformed(evt);
            }
        });

        btnxoaCaLam.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnxoaCaLam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Actions-edit-delete-icon-16.png"))); // NOI18N
        btnxoaCaLam.setText("Xóa ca làm");
        btnxoaCaLam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnxoaCaLamActionPerformed(evt);
            }
        });

        tbdanhSachNVcl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Họ tên", "Chức vụ"
            }
        ));
        tbdanhSachNVcl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbdanhSachNVclMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbdanhSachNVcl);

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel23.setText("Danh sách nhân viên");

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/logout-icon-16.png"))); // NOI18N
        jButton3.setText("Thoát");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btnthemCaLam)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnsuaCaLam)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnxoaCaLam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 477, Short.MAX_VALUE)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel23)))
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel23)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnthemCaLam)
                            .addComponent(btnsuaCaLam)
                            .addComponent(btnxoaCaLam))
                        .addGap(29, 29, 29)
                        .addComponent(jButton3)
                        .addGap(0, 87, Short.MAX_VALUE))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane2.addTab("Ca làm", jPanel8);

        jLabel24.setText("Mã nhân viên:");

        jLabel25.setText("Họ tên:");

        jLabel26.setText("Chức vụ:");

        tbluong.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Họ tên", "Chức vụ", "Số ngày làm", "Đơn giá lương", "Tổng lương (Nghìn đồng)"
            }
        ));
        jScrollPane5.setViewportView(tbluong);

        tbdanhSachNVl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Họ tên", "Chức vụ"
            }
        ));
        tbdanhSachNVl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbdanhSachNVlMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tbdanhSachNVl);

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel27.setText("NGÀY TÍNH LƯƠNG");

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel28.setText("TỪ NGÀY:");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel29.setText("ĐẾN NGÀY:");

        jLabel30.setText("Ngày:");

        cbngayltu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        jLabel31.setText("Tháng:");

        cbthangltu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));

        jLabel32.setText("Năm:");

        cbnamltu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "2022" }));

        cbnamlden.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "2022" }));

        cbthanglden.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));

        cbngaylden.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        jLabel33.setText("Ngày:");

        jLabel34.setText("Tháng:");

        jLabel35.setText("Năm:");

        tinhLuong.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tinhLuong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/Actions-document-edit-icon-16.png"))); // NOI18N
        tinhLuong.setText("Tính Lương");
        tinhLuong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tinhLuongActionPerformed(evt);
            }
        });

        btnlamMoi.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnlamMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/new-icon-16.png"))); // NOI18N
        btnlamMoi.setText("Làm mới");
        btnlamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlamMoiActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Main/icons/logout-icon-16.png"))); // NOI18N
        jButton4.setText("Thoát");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(jLabel25)
                            .addComponent(jLabel26))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtmaNhanVienl, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(txthoTenl)
                            .addComponent(txtchucVul))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, Short.MAX_VALUE)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addComponent(jLabel28)
                                        .addGap(58, 58, 58)
                                        .addComponent(jLabel30)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbngayltu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel31))
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addComponent(jLabel29)
                                        .addGap(50, 50, 50)
                                        .addComponent(jLabel33)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbngaylden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel34)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbthanglden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbthangltu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel32))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbnamlden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addComponent(cbnamltu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(59, 59, 59)
                                        .addComponent(tinhLuong)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnlamMoi)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton4)))))
                        .addGap(0, 115, Short.MAX_VALUE))))
            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(txtmaNhanVienl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(txthoTenl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(txtchucVul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23))
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addComponent(jLabel27)
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(jLabel30)
                    .addComponent(cbngayltu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31)
                    .addComponent(cbthangltu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32)
                    .addComponent(cbnamltu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tinhLuong)
                    .addComponent(btnlamMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4))
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbngaylden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbthanglden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel34)
                    .addComponent(jLabel29)
                    .addComponent(jLabel33)
                    .addComponent(jLabel35)
                    .addComponent(cbnamlden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane2.addTab("Lương", jPanel9);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnlamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlamMoiActionPerformed
        // TODO add your handling code here:
        txtmaNhanVienl.setText("");
        txthoTenl.setText("");
        txtchucVul.setText("");
    }//GEN-LAST:event_btnlamMoiActionPerformed

    private void tinhLuongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tinhLuongActionPerformed
        // TODO add your handling code here:
        StringBuilder sb = new StringBuilder();
        if (txtmaNhanVienl.getText().equals("")) {
            sb.append("Mã nhân viên không hợp lệ!\n");
            txtmaNhanVienl.setBackground(Color.red);
        } else {
            String sql = "select * from luong";
            try {
                Connection con = DatabaseHelper.openConnection();
                PreparedStatement pstmt = con.prepareStatement(sql);
                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    String checkMa = rs.getString("maNV");
                    if (checkMa.equals(txtmaNhanVienl.getText())) {
                        sb.append("Nhân viên này đã được tính lương rồi. Mời chọn nhân viên khác\n");
                        txtmaNhanVienl.setBackground(Color.red);
                    } else {
                        txtmaNhanVienl.setBackground(Color.white);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (txthoTenl.getText().equals("")) {
            sb.append("Họ tên nhân viên không được rỗng!\n");
            txthoTenl.setBackground(Color.red);
        } else {
            txthoTenl.setBackground(Color.white);
        }
        if (txtchucVul.getText().equals("")) {
            sb.append("Chức vụ không được rỗng!\n");
            txtchucVul.setBackground(Color.red);
        } else {
            txtchucVul.setBackground(Color.white);
        }
        String luongTu = new String();
        luongTu = cbngayltu.getSelectedItem() + "/" + cbthangltu + "/" + cbnamltu.getSelectedItem();
        String luongDen = new String();
        luongDen = cbngaylden.getSelectedItem() + "/" + cbthanglden + "/" + cbnamlden.getSelectedItem();
        if (cbngayltu.getSelectedItem().equals("...") || cbthangltu.getSelectedItem().equals("...") || cbnamltu.getSelectedItem().equals("...")) {
            sb.append("Mời bạn chọn ngày bắt đầu tính lương!\n");
        } else {
            if (laNgayHopLe(Integer.parseInt(cbngayltu.getSelectedItem().toString()), Integer.parseInt(cbthangltu.getSelectedItem().toString()), Integer.parseInt(cbnamltu.getSelectedItem().toString())) == false) {
                sb.append("Ngày bắt đầu không hợp lệ!\n");
            } else {
                if (cbngaylden.getSelectedItem().equals("...") || cbthanglden.getSelectedItem().equals("...") || cbnamlden.getSelectedItem().equals("...")) {
                    sb.append("Mời bạn chọn ngày tính lương!\n");
                } else {
                    if (laNgayHopLe(Integer.parseInt(cbngaylden.getSelectedItem().toString()), Integer.parseInt(cbthanglden.getSelectedItem().toString()), Integer.parseInt(cbnamlden.getSelectedItem().toString())) == false) {
                        sb.append("Ngày tính lương không hợp lệ!\n");
                    } else {
                        if (luongTu.compareTo(luongDen) >= 0) {
                            sb.append("Ngày bắt đầu tính lương phải nhỏ hơn ngày tính lương!\n");
                        }
                    }
                }
            }

        }

        if (sb.length() > 0) {
            JOptionPane.showMessageDialog(this, sb);
            return;
        }
        try {

            String tenNVl = txthoTenl.getText();
            String chucVul = txtchucVucl.getText();
            int soNgayLam = demSoCaLam(tenNVl);
            int donGia = donGiaLuong(chucVul);
            int tienLuong = soNgayLam * donGia;

            Connection con = DatabaseHelper.openConnection();
            String sql = "insert into luong(maNV, hoTen, chucVu, soNgayLam, donGiaLuong, tongLuong)values(?,?,?,?,?,?)";
            PreparedStatement pstmt = con.prepareStatement(sql);

            pstmt.setString(1, txtmaNhanVienl.getText());
            pstmt.setString(2, txthoTenl.getText());
            pstmt.setString(3, txtchucVul.getText());
            pstmt.setInt(4, soNgayLam);
            pstmt.setInt(5, donGia);
            pstmt.setInt(6, tienLuong);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Hoàn tất tính lương");
            loadEmployee();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tinhLuongActionPerformed

    private void tbdanhSachNVlMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbdanhSachNVlMouseClicked
        // TODO add your handling code here:
        int row = tbdanhSachNVl.getSelectedRow();
        if (row >= 0) {
            txtmaNhanVienl.setText(tbdanhSachNVl.getValueAt(row, 0).toString());
            txthoTenl.setText(tbdanhSachNVl.getValueAt(row, 1).toString());
            txtchucVul.setText(tbdanhSachNVl.getValueAt(row, 2).toString());
        }
    }//GEN-LAST:event_tbdanhSachNVlMouseClicked

    private void tbdanhSachNVclMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbdanhSachNVclMouseClicked
        // TODO add your handling code here:
        int row = tbdanhSachNVcl.getSelectedRow();
        if (row >= 0) {
            txthoTencl.setText(tbdanhSachNVcl.getValueAt(row, 1).toString());
            txtchucVucl.setText(tbdanhSachNVcl.getValueAt(row, 2).toString());
        }
    }//GEN-LAST:event_tbdanhSachNVclMouseClicked

    private void btnxoaCaLamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnxoaCaLamActionPerformed
        // TODO add your handling code here:
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn xóa ca làm này không?") == JOptionPane.NO_OPTION) {
            return;
        }
        try {
            caLamDao dao = new caLamDao();
            dao.delete(txtmaCacl.getText());
            JOptionPane.showMessageDialog(this, "Xóa ca làm thành công!");
            loadEmployee();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnxoaCaLamActionPerformed

    private void btnsuaCaLamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsuaCaLamActionPerformed
        // TODO add your handling code here:
        StringBuilder sb = new StringBuilder();
        if (txtmaCacl.getText().equals("")) {
            sb.append("Mã ca làm không hợp lệ!\n");
            txtmaCacl.setBackground(Color.red);
        } else {
            txtmaCacl.setBackground(Color.white);
        }
        if (txthoTencl.getText().equals("")) {
            sb.append("Họ tên nhân viên không được rỗng!\n");
            txthoTencl.setBackground(Color.red);
        } else {
            txthoTencl.setBackground(Color.white);
        }
        if (txtchucVucl.getText().equals("")) {
            sb.append("Chức vụ không được rỗng!\n");
            txtchucVucl.setBackground(Color.red);
        } else {
            txtchucVucl.setBackground(Color.white);
        }
        if (cbngaycl.getSelectedItem().equals("...") || cbthangcl.getSelectedItem().equals("...") || cbnamcl.getSelectedItem().equals("...")) {
            sb.append("Mời bạn chọn ngày làm!\n");
        } else {
            if (laNgayHopLe(Integer.parseInt(cbngaycl.getSelectedItem().toString()), Integer.parseInt(cbthangcl.getSelectedItem().toString()), Integer.parseInt(cbnamcl.getSelectedItem().toString())) == false) {
                sb.append("Ngày làm không hợp lệ!\n");
            } else {
                if (!checkDate(cbngaycl.getSelectedItem() + "/" + cbthangcl.getSelectedItem() + "/" + cbnamcl.getSelectedItem())) {
                    sb.append("Ngày làm phải lớn hơn ngày hiện tại.\n");
                }
            }
        }
        if (cbbuoicl.getSelectedItem().equals("...")) {
            sb.append("Mời bạn chọn buổi làm!\n");
        }
        if (sb.length() > 0) {
            JOptionPane.showMessageDialog(this, sb);
            return;
        }

        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn cập nhật ca làm này không?") == JOptionPane.NO_OPTION) {
            return;
        }

        try {
            CaLam cl = new CaLam();
            cl.setMaCa(txtmaCacl.getText());
            cl.setHoTen(txthoTencl.getText());
            String nl = new String();
            nl = cbngaycl.getSelectedItem() + "/" + cbthangcl.getSelectedItem() + "/" + cbnamcl.getSelectedItem();
            cl.setNgayLam(nl);
            cl.setChucVu(txtchucVucl.getText());
            cl.setBuoi(cbbuoicl.getSelectedItem().toString());
            caLamDao dao = new caLamDao();
            dao.update(cl);

            JOptionPane.showMessageDialog(this, "Cập nhật ca làm thành công!");
            loadEmployee();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnsuaCaLamActionPerformed

    private void btnthemCaLamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnthemCaLamActionPerformed
        // TODO add your handling code here:

        StringBuilder sb = new StringBuilder();
        if (txtmaCacl.getText().equals("")) {
            sb.append("Mã ca làm không hợp lệ!\n");
            txtmaCacl.setBackground(Color.red);
        } else {
            if (!isNumeric(txtmaCacl.getText())) {
                sb.append("Mã ca phải là số");
                txtmaCacl.setBackground(Color.red);
            } else {
                String sql = "select * from ObjcaLam";
                try {
                    Connection con = DatabaseHelper.openConnection();
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    ResultSet rs = pstmt.executeQuery();
                    while (rs.next()) {
                        String checkMa = rs.getString("maCa");
                        if (checkMa.equals(txtmaCacl.getText())) {
                            sb.append("Mã Ca làm đã trùng!\n");
                            txtmaCacl.setBackground(Color.red);
                        } else {
                            txtmaCacl.setBackground(Color.white);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            txtmaNhanVien.setBackground(Color.white);
        }
        if (txthoTencl.getText().equals("")) {
            sb.append("Họ tên nhân viên không được rỗng!\n");
            txthoTencl.setBackground(Color.red);
        } else {
            txthoTencl.setBackground(Color.white);
        }
        if (txtchucVucl.getText().equals("")) {
            sb.append("Chức vụ không được rỗng!\n");
            txtchucVucl.setBackground(Color.red);
        } else {
            txtchucVucl.setBackground(Color.white);
        }
//        if (cbngaycl.getSelectedItem().equals("...") || cbthangcl.getSelectedItem().equals("...") || cbnamcl.getSelectedItem().equals("...")) {
//            sb.append("Mời bạn chọn ngày làm!\n");
//        } else {
//            if (laNgayHopLe(Integer.parseInt(cbngaycl.getSelectedItem().toString()), Integer.parseInt(cbthangcl.getSelectedItem().toString()), Integer.parseInt(cbnamcl.getSelectedItem().toString())) == false) {
//                sb.append("Ngày làm không hợp lệ!\n");
//            } else {
//                if (!checkDate(cbngaycl.getSelectedItem() + "/" + cbthangcl.getSelectedItem() + "/" + cbnamcl.getSelectedItem())) {
//                    sb.append("Ngày làm phải lớn hơn ngày hiện tại.\n");
//                }
//            }
//        }
        if (cbbuoicl.getSelectedItem().equals("...")) {
            sb.append("Mời bạn chọn buổi làm!\n");
        }
        if (sb.length() > 0) {
            JOptionPane.showMessageDialog(this, sb);
            return;
        }
        //

        //
        try {
            CaLam cl = new CaLam();
            cl.setMaCa(txtmaCacl.getText());
            cl.setHoTen(txthoTencl.getText());
            String nl = new String();
            nl = cbngaycl.getSelectedItem() + "/" + cbthangcl.getSelectedItem() + "/" + cbnamcl.getSelectedItem();
            cl.setNgayLam(nl);
            cl.setChucVu(txtchucVucl.getText());
            cl.setBuoi(cbbuoicl.getSelectedItem().toString());
            caLamDao dao = new caLamDao();
            dao.insert(cl);

            //            MaCaIncrease mI = new MaCaIncrease();
            //            mI.Increase(maCaDefault);
            JOptionPane.showMessageDialog(this, "Lưu thông tin thành công!");
            loadEmployee();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnthemCaLamActionPerformed

    private void tbcaLamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbcaLamMouseClicked
        // TODO add your handling code here:
        int row = tbcaLam.getSelectedRow();
        if (row >= 0) {
            txtmaCacl.setText(tbcaLam.getValueAt(row, 0).toString());
            txthoTencl.setText(tbcaLam.getValueAt(row, 1).toString());
            txtchucVucl.setText(tbcaLam.getValueAt(row, 2).toString());
            String ngayLam = new String();
            ngayLam = tbcaLam.getValueAt(row, 3).toString();
            String part[] = ngayLam.split("/");
            String part1 = part[0];
            String part2 = part[1];
            String part3 = part[2];
            cbngaycl.setSelectedItem(part1);
            cbthangcl.setSelectedItem(part2);
            cbnamcl.setSelectedItem(part3);
            cbbuoicl.setSelectedItem(tbcaLam.getValueAt(row, 4).toString());
        }
    }//GEN-LAST:event_tbcaLamMouseClicked

    private void btncapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncapNhatActionPerformed
        // TODO add your handling code here:
        StringBuilder sb = new StringBuilder();
        if (txtmaNhanVien.getText().equals("")) {
            sb.append("Mã nhân viên không được rỗng!\n");
            txtmaNhanVien.setBackground(Color.red);
        } else {
            txtmaNhanVien.setBackground(Color.white);
            if (!isNumeric(txtmaNhanVien.getText())) {
                sb.append("Mã Nhân yêu cầu phải là số!\n");
                txtmaNhanVien.setBackground(Color.red);
            } else {
                txtmaNhanVien.setBackground(Color.white);
            }
        }
        if (txthoTen.getText().equals("")) {
            sb.append("Họ tên nhân viên không được rỗng!\n");
            txthoTen.setBackground(Color.red);
        } else {
            txthoTen.setBackground(Color.white);
        }
        if (!rdbnam.isSelected() && !rdbnu.isSelected()) {
            sb.append("Yêu cầu chọn giới tính!\n");
        }
        if (cbngay.getSelectedItem().equals("...") || cbthang.getSelectedItem().equals("...") || cbnam.getSelectedItem().equals("...")) {
            sb.append("Vui lòng nhập ngày, tháng, năm sinh!\n");
        } else {
            if (laNgayHopLe(Integer.parseInt(cbngay.getSelectedItem().toString()), Integer.parseInt(cbthang.getSelectedItem().toString()), Integer.parseInt(cbnam.getSelectedItem().toString())) == false) {
                sb.append("Ngày sinh không hợp lệ!\n");
            }
        }
        if (txtsoDienThoai.getText().equals("")) {
            sb.append("Số điện thoại không được rỗng!\n");
            txtsoDienThoai.setBackground(Color.red);
        } else {
            txtsoDienThoai.setBackground(Color.white);
        }
        if (txtadiaChi.getText().equals("")) {
            sb.append("Địa chỉ không được rỗng!\n");
            txtadiaChi.setBackground(Color.red);
        } else {
            txtadiaChi.setBackground(Color.white);
        }
        if (cbchucVu.getSelectedItem().equals("...")) {
            sb.append("Chức vụ không hợp lệ!\n");
        }
        if (sb.length() > 0) {
            JOptionPane.showMessageDialog(this, sb);
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn cập nhật thông tin về nhân viên này không?") == JOptionPane.NO_OPTION) {
            return;
        }
        try {
            NhanVien nv = new NhanVien();
            nv.setMaNV(txtmaNhanVien.getText());
            nv.setHoTen(txthoTen.getText());
            String gender = "";
            if (rdbnam.isSelected()) {
                gender = "Nam";
            }
            if (rdbnu.isSelected()) {
                gender = "Nu";
            }
            nv.setGioiTinh(gender);
            String ns = new String();
            ns = cbngay.getSelectedItem() + "/" + cbthang.getSelectedItem() + "/" + cbnam.getSelectedItem();
            nv.setNgaySinh(ns);
            nv.setSdt(txtsoDienThoai.getText());
            nv.setDiaChi(txtadiaChi.getText());
            String cv = String.valueOf(cbchucVu.getSelectedItem());
            nv.setChucVu(cv);

            NhanVienDao dao = new NhanVienDao();
            dao.update(nv);

            JOptionPane.showMessageDialog(this, "Cập nhật thông tin thành công!");
            loadEmployee();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btncapNhatActionPerformed

    private void btnluuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnluuActionPerformed
        StringBuilder sb = new StringBuilder();
        if (txtmaNhanVien.getText().equals("")) {
            sb.append("Mã nhân viên không được rỗng!\n");
            txtmaNhanVien.setBackground(Color.red);
        } else {
            txtmaNhanVien.setBackground(Color.white);
            if (!isNumeric(txtmaNhanVien.getText())) {
                sb.append("Mã Nhân yêu cầu phải là số!\n");
                txtmaNhanVien.setBackground(Color.red);
            } else {
                String sql = "select * from ObjnhanVien";
                try {
                    Connection con = DatabaseHelper.openConnection();
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    ResultSet rs = pstmt.executeQuery();
                    while (rs.next()) {
                        String checkMa = rs.getString("maNV");
                        if (checkMa.equals(txtmaNhanVien.getText())) {
                            sb.append("Mã nhân viên đã trùng! Vui lòng nhập lại\n");
                            txtmaNhanVien.setBackground(Color.red);
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            txtmaNhanVien.setBackground(Color.white);
        }
        if (txthoTen.getText().equals("")) {
            sb.append("Họ tên nhân viên không được rỗng!\n");
            txthoTen.setBackground(Color.red);
        } else {
            txthoTen.setBackground(Color.white);
        }
        if (!rdbnam.isSelected() && !rdbnu.isSelected()) {
            sb.append("Yêu cầu chọn giới tính!\n");
        }
        if (cbngay.getSelectedItem().equals("...") || cbthang.getSelectedItem().equals("...") || cbnam.getSelectedItem().equals("...")) {
            sb.append("Vui lòng chọn ngày, tháng, năm sinh!\n");
        } else {
            if (laNgayHopLe(Integer.parseInt(cbngay.getSelectedItem().toString()), Integer.parseInt(cbthang.getSelectedItem().toString()), Integer.parseInt(cbnam.getSelectedItem().toString())) == false) {
                sb.append("Ngày sinh không hợp lệ!\n");
            }
        }
        if (txtsoDienThoai.getText().equals("")) {
            sb.append("Số điện thoại không được rỗng!\n");
            txtsoDienThoai.setBackground(Color.red);
        } else {
            txtsoDienThoai.setBackground(Color.white);
        }
        if (txtadiaChi.getText().equals("")) {
            sb.append("Địa chỉ không được rỗng!\n");
            txtadiaChi.setBackground(Color.red);
        } else {
            txtadiaChi.setBackground(Color.white);
        }
        if (cbchucVu.getSelectedItem().equals("...")) {
            sb.append("Chức vụ không hợp lệ!\n");
        }
        if (sb.length() > 0) {
            JOptionPane.showMessageDialog(this, sb);
            return;
        }

        try {
            NhanVien nv = new NhanVien();
            nv.setMaNV(txtmaNhanVien.getText());
            nv.setHoTen(txthoTen.getText());
            String gender = "";
            if (rdbnam.isSelected()) {
                gender = "Nam";
            }
            if (rdbnu.isSelected()) {
                gender = "Nu";
            }
            nv.setGioiTinh(gender);
            String ns = new String();
            ns = cbngay.getSelectedItem() + "/" + cbthang.getSelectedItem() + "/" + cbnam.getSelectedItem();
            nv.setNgaySinh(ns);
            nv.setSdt(txtsoDienThoai.getText());
            nv.setDiaChi(txtadiaChi.getText());
            String cv = String.valueOf(cbchucVu.getSelectedItem());
            nv.setChucVu(cv);

            NhanVienDao dao = new NhanVienDao();
            dao.insert(nv);

            JOptionPane.showMessageDialog(this, "Lưu thông tin thành công!");
            loadEmployee();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnluuActionPerformed

    private void btnxoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnxoaActionPerformed

        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn xóa thông tin về nhân viên này không?") == JOptionPane.NO_OPTION) {
            return;
        }
        try {

            NhanVienDao dao = new NhanVienDao();
            dao.delete(txtmaNhanVien.getText());

            JOptionPane.showMessageDialog(this, "Đã xóa thông tin thành công!");
            loadEmployee();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnxoaActionPerformed

    private void btnnhapMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnhapMoiActionPerformed
        // TODO add your handling code here:
        txtmaNhanVien.setText("");
        txthoTen.setText("");
        txtsoDienThoai.setText("");
        txtadiaChi.setText("");
        cbchucVu.setSelectedIndex(0);
        cbngay.setSelectedIndex(0);
        cbthang.setSelectedIndex(0);
        cbnam.setSelectedIndex(0);
        rdbnam.setSelected(false);
        rdbnu.setSelected(false);
    }//GEN-LAST:event_btnnhapMoiActionPerformed

    private void tbdanhSachNVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbdanhSachNVMouseClicked
        // TODO add your handling code here:
        int row = tbdanhSachNV.getSelectedRow();
        if (row >= 0) {
            txtmaNhanVien.setText(tbdanhSachNV.getValueAt(row, 0).toString());
            txthoTen.setText(tbdanhSachNV.getValueAt(row, 1).toString());
            txtadiaChi.setText(tbdanhSachNV.getValueAt(row, 5).toString());
            txtsoDienThoai.setText(tbdanhSachNV.getValueAt(row, 4).toString());
            String dayofbirth = new String();
            dayofbirth = tbdanhSachNV.getValueAt(row, 3).toString();
            String part[] = dayofbirth.split("/");
            String part1 = part[0];
            String part2 = part[1];
            String part3 = part[2];
            cbngay.setSelectedItem(part1);
            cbthang.setSelectedItem(part2);
            cbnam.setSelectedItem(part3);
            cbchucVu.setSelectedItem(tbdanhSachNV.getValueAt(row, 6));

        }
    }//GEN-LAST:event_tbdanhSachNVMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn đăng xuất không?") == JOptionPane.NO_OPTION) {
            return;
        }
        try {
            this.setVisible(false);
            Login lg = new Login();
            lg.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed
    public static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }//ValidateDate

    private boolean laNamNhuan(int Nam) {
        if ((Nam % 4 == 0 && Nam % 100 != 0) || Nam % 400 == 0) {
            return true;
        } else {
            return false;
        }
    }

    int tinhSoNgay(int thang, int nam) {
        int songay = 0;
        switch (thang) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                songay = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                songay = 30;
                break;
            case 2: {
                if (laNamNhuan(nam)) {
                    songay = 29;
                } else {
                    songay = 28;
                }
                break;
            }
        }
        return songay;
    }

    private boolean laNgayHopLe(int nDay, int nMonth, int nYear) {
        if (nYear < 0) {
            return false;
        }
        if (nMonth < 1 || nMonth > 12) {
            return false;
        }
        if (nDay < 1 || nDay > tinhSoNgay(nMonth, nYear)) {
            return false;
        }
        return true;
    }

    public boolean checkDate(String date) {
        java.util.Date presentDate = new java.util.Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        try {
            java.util.Date inputDate = formatter.parse(date);
            return inputDate.after(presentDate);
        } catch (ParseException ex) {
            Logger.getLogger(EmployeeInfo.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    int donGiaLuong(String chucVu) {
        int donGia = 0;
        if (txtchucVul.getText().equals("Quan ly")) {
            donGia = 110;
        }
        if (txtchucVul.getText().equals("Phuc vu")) {
            donGia = 105;
        }
        if (txtchucVul.getText().equals("Le tan")) {
            donGia = 105;
        }
        if (txtchucVul.getText().equals("Don dep")) {
            donGia = 100;
        }
        if (txtchucVul.getText().equals("Bao ve")) {
            donGia = 95;
        }
        return donGia;
    }

    int demSoCaLam(String tenNV) throws Exception {
        int soNgay = 0;
        Connection con = DatabaseHelper.openConnection();
        String sql = "select * from ObjcaLam";
        PreparedStatement pstmt = con.prepareStatement(sql);

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            String checkMa = new String();
            checkMa = rs.getString("hoTen");
            if (checkMa.equals(tenNV)) {
                soNgay += 1;
            }
        }
        return soNgay;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncapNhat;
    private javax.swing.JButton btnlamMoi;
    private javax.swing.JButton btnluu;
    private javax.swing.JButton btnnhapMoi;
    private javax.swing.JButton btnsuaCaLam;
    private javax.swing.JButton btnthemCaLam;
    private javax.swing.JButton btnxoa;
    private javax.swing.JButton btnxoaCaLam;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbbuoicl;
    private javax.swing.JComboBox<String> cbchucVu;
    private javax.swing.JComboBox<String> cbnam;
    private javax.swing.JComboBox<String> cbnamcl;
    private javax.swing.JComboBox<String> cbnamlden;
    private javax.swing.JComboBox<String> cbnamltu;
    private javax.swing.JComboBox<String> cbngay;
    private javax.swing.JComboBox<String> cbngaycl;
    private javax.swing.JComboBox<String> cbngaylden;
    private javax.swing.JComboBox<String> cbngayltu;
    private javax.swing.JComboBox<String> cbthang;
    private javax.swing.JComboBox<String> cbthangcl;
    private javax.swing.JComboBox<String> cbthanglden;
    private javax.swing.JComboBox<String> cbthangltu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JRadioButton rdbnam;
    private javax.swing.JRadioButton rdbnu;
    private javax.swing.JTable tbcaLam;
    private javax.swing.JTable tbdanhSachNV;
    private javax.swing.JTable tbdanhSachNVcl;
    private javax.swing.JTable tbdanhSachNVl;
    private javax.swing.JTable tbluong;
    private javax.swing.JButton tinhLuong;
    private javax.swing.JTextArea txtadiaChi;
    private javax.swing.JTextField txtchucVucl;
    private javax.swing.JTextField txtchucVul;
    private javax.swing.JTextField txthoTen;
    private javax.swing.JTextField txthoTencl;
    private javax.swing.JTextField txthoTenl;
    private javax.swing.JTextField txtmaCacl;
    private javax.swing.JTextField txtmaNhanVien;
    private javax.swing.JTextField txtmaNhanVienl;
    private javax.swing.JTextField txtsoDienThoai;
    // End of variables declaration//GEN-END:variables
}
